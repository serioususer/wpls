#!/usr/bin/env python2
# -*- coding: UTF-8 -*-

##############################################
##############################################
##   PhySec-Praktikum Framework 2019        ##
##   Authors: Jan Zimmer                    ##
##            Jeremy Brauer                 ##
##                                          ##
##   Students:   <Daniel Pantjuskin-Moos>   ##
##               <108013248222>             ##
##               <Vincent Koenig>           ##
##   Student-ID: <108011232630>             ##
##                                          ##
##   DO ONLY CHANGE MARKED FUNCTION BODIES  ##
##                                          ##
##############################################
##############################################


import utils
import numpy

"""
Excersise 3:
Implement the Pearson correlation coefficient.
Do NOT use any given function for standard-deviation or mean-value but implement them by yourself.

X, Y are given as lists.

Blockwise application is done outside so please use the whole vectors at once.
"""

def correlation(X, Y):
    mean_x = numpy.mean(X)
    mean_y = numpy.mean(Y)

    zaehler = 0
    sum1 = 0
    sum2 = 0

    if len(X) != len(Y):
        raise Exception("Length not equal!\n")

   
    for i in range(len(X)):
        zaehler += (X[i] - mean_x)*(Y[i] - mean_y)
        sum1 += (X[i]-mean_x)*(X[i]-mean_x)
        sum2 += (Y[i]-mean_y)*(Y[i]-mean_y)

    nenner = numpy.sqrt(sum1*sum2)

    if nenner == 0:
        return float('nan')

    pearson = zaehler/nenner
    
    
    return pearson


#Testvektoren aus:
#https://www.youtube.com/watch?v=2B_UW-RweSE
# I = [18, 25, 57, 45, 26, 64, 37, 40, 24, 33]
# J = [15000, 29000, 68000, 52000, 32000, 80000, 41000, 45000, 26000, 33000]
# print( correlation(I, J))  # Ergebnis sollte laut Video 0.99 sein

# # Testvektoren aus:
# # https://youtu.be/rDlhliU7luo?t=128
# K = [180.2, 120, 172.3, 26.8, 120, 105.5, 285.3,
#      199.6, 52.9, 187.1, 220, 236.4, 61.5, 218.6]
# L = [53.2, 47.3, 38, 18, 32.2, 24.8, 63.2, 44.9, 33.6, 38, 58.3, 42, 28.3, 45]
# correlation(K, L)  # Ergebnis sollte etwa 0.8251 sein

# # Testvektoren aus A.scv und B.csv entnommen
# M = [-70, -63, -61, -61, -60, -58, -61, -62, -61, -64]
# N = [-56, -57, -68, -67, -63, -64, -67, -71, -62, -61]
# # Ergebnis sollte etwa -0.593640241393 sein laut der moodle file correlation_AB.csv
# correlation(M, N)



# Ausgaben
# 0.9922852587629403
# 0.8251288095907297
# -0.5936402413930395

"""
Example mean-quantizer.
"""


# A, B, E are lists. Args is not used here but might be necessary when it comes to Q1 and Q2.
def quant0(A, B, E, args):
    # Q maps to 1 if x>t. Otherwise Q maps to 0.
    def Q(x, t): return 1 if x > t else 0
    bA = map(Q, A, [numpy.mean(A)
                    for i in range(len(A))])  # bA[i]=Q(A[i], mean(A))
    bB = map(Q, B, [numpy.mean(B) for i in range(len(B))])
    bE = map(Q, E, [numpy.mean(E) for i in range(len(E))])
    return bA, bB, bE
